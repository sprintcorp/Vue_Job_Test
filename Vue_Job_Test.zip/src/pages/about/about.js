export default {
  data() {
    return {
      e6: 5,
    };
  },
};
